const firebaseConfig = {
  apiKey: "AIzaSyAk2lv6TfKIiptdEKooSU0NmEde94R2EHM",
  authDomain: "uttt-f1f02.firebaseapp.com",
  databaseURL: "https://uttt-f1f02-default-rtdb.firebaseio.com",
  projectId: "uttt-f1f02",
  storageBucket: "uttt-f1f02.firebasestorage.app",
  messagingSenderId: "243007886313",
  appId: "1:243007886313:web:d4cf31cbf44faa0c207178",
  measurementId: "G-D4GDK6NXZ1"
};
firebase.initializeApp(firebaseConfig);